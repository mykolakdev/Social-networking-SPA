<?php

namespace App\Http\Controllers;

use App\Post;
use App\Usecases\Posts\CreatePost;
use App\Usecases\Posts\ICreatePost;
use Illuminate\Http\Request;
use App\Http\Resources\Post as PostResource;

class PostController extends Controller
{
    private $CreatePost;

    public function __construct(ICreatePost $CreatePost)
    {
        $this->CreatePost = new $CreatePost();
    }

    public function store()
    {
        $data = request()->validate([
            'data.attributes.body' => '',
        ]);

        $user = request()->user();
        $postCreator = $this->CreatePost($user, $data);
        $post = $postCreator->execute();

        return new PostResource($post);
    }
}

