<?php


namespace App\Usecases\Posts;


interface ICreatePost
{
    public function execute();
}
